(function() {
var roll = Roll.DOM( "#wrapper", "#pane", "#steps", ".step", 100 );
var views = document.querySelectorAll( ".step" );
views[0].className = "step curr";
function track() {
function _vendor( elem, prop, val ) {
 var vs = ["webkit", "Webkit", "Moz", "ms"];
for (var i=0; i<vs.length; i++) {
elem.style[ vs[i]+prop ] = val;
}
}
roll.on( "step", Roll.stepHandler( roll, views, "prev", "next", "curr", true ) );
roll.on( "roll", function ( step, stepProgress, position, totalProgress ) {
var curr = (step >= 0) ? "Step "+(step+1) : "(padding)";
 var vals = {
numSteps: roll.steps.length,
 viewportHeight: roll.getViewportHeight(),
paneHeight: roll.getHeight(),
currStep: curr,
currPos: position + "px",
currStepProgress: Math.floor( stepProgress * 100 ) + "%",
totalProgress: Math.floor( totalProgress * 100) + "%"
};
for (var k in vals) {
 var el = document.querySelector("#"+k);
if (el) {
 el.textContent = vals[k];
}
}
if (step >= 0) {
 var currStep = document.querySelector( "#s" + step );
 var ings = currStep.querySelectorAll( ".ingredient" );
for (var i = 0; i < ings.length; i++) {
 var ang1 = parseInt( ings[i].getAttribute( "data-angle" ) );
 var ang2 = parseInt( ings[i].getAttribute( "data-rotate" ) );
 var tm = "scale(" + (0.25 + totalProgress * 0.5) + ") translate(0, "+Math.floor(-ang1*stepProgress*3)+"px)";
 ings[i].style.transform = tm;
_vendor( ings[i], "Transform", tm );
 }
} 
 var progress = document.querySelector("#progress");
 progress.style.height = Math.floor(roll.getViewportHeight() * totalProgress) + "px";
 });
}
track();
window.goto = function(index) {
var viewport = document.querySelector( "#wrapper" );
roll.scroll(index, viewport);
};
window.addEventListener("resize", function(evt) {
roll = Roll.DOM( "#wrapper", "#pane", "#steps", ".step", 100 );
track();
goto(0);
});
goto(0);
})();