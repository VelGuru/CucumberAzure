[CmdletBinding()]
param($dllpath,$jsonpath,$vsaccount,$project)

# For more information on the VSTS Task SDK:
# https://github.com/Microsoft/vsts-task-lib
Import-Module -Name $dllpath -Verbose

Trace-VstsEnteringInvocation $MyInvocation
try {

      # Get the inputs.
    [string]$testResultPath = "target"
    [string]$username = "797041@cognizant.com"
    [string]$password = "Guru#1994"
    [string]$outputFolder = "target"
    [string]$jsonMapping = $jsonpath  
    [string]$inputType = "file"
    if($inputType -eq "file"){
              $jsonMapping = $jsonpath
              Write-host "Using file $jsonMapping for JSON mapping"
    }
    else
    {
        Write-host "-----------------------"
        Write-host "Json test mapping"
        Write-host "-----------------------"
        Write-host `"$jsonMapping`"
    }

    
    $vsoAccountName = $vsaccount
    $projectName = $project

    Write-host "-----------------------"
    Write-host "Config"
    Write-host "-----------------------"
    Write-host "Tests path= $testResultPath"
    Write-host "Project name (var)= $projectName"
    Write-host "Visual Studio Account name (var)= $vsoAccountName"
    Write-host "Output folder= $outputFolder"

    #Set the working directory.
    $cwd = "bin"
    Assert-VstsPath -LiteralPath $cwd -PathType Container
    Write-host "Setting working directory to '$cwd'."
    Set-Location $cwd

    Write-host "Creation of dynamic .NET DLL using ROSLYN..."
    Write-host "-------------------------------------------------"

    Invoke-VstsTool -FileName ".\UnitTestGenerator\Microsoft.DX.JavaTestBridge.UnitTestGenerator.exe" -Arguments "AutomatedTestAssembly `"$jsonMapping`" $testResultPath" -RequireExitCodeZero
    
    if($LASTEXITCODE -eq 0){

        Write-host ".NET Unit test assembly created (AutomatedTestAssembly.dll)"
        
        Write-host "Association of tests with VSTS..."
        Write-host "-------------------------------------------------"

        Invoke-VstsTool -FileName ".\VSTS\Microsoft.DX.JavaTestBridge.VSTS.exe" -Arguments "$vsoAccountName $projectName AutomatedTestAssembly.dll $username $password" -RequireExitCodeZero
        if($LASTEXITCODE -eq 0)
        {
          Write-host "Association completed successfully"
         
          #required DLL to run
          Move-Item .\AutomatedTestAssembly.dll $outputFolder -Force
          Copy-Item .\Newtonsoft.Json.dll $outputFolder -Force
          Copy-Item .\Microsoft.DX.JavaTestBridge.Common.dll $outputFolder -Force

          Write-host "Files copied to $outputFolder"
        }
        else
        {
            Write-Error "Association of tests failed"
        }
    }
    else
    {
      Write-Error "Creation of .NET dynamic test DLL failed";
    }

   
} finally {
    Trace-VstsLeavingInvocation $MyInvocation
}